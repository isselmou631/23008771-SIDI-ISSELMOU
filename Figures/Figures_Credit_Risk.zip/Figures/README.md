# Figures — Projet F1 : Credit Risk

Les neuf figures ci-dessous ont été extraites des sorties déjà enregistrées dans le notebook `projet_F1_credit_risk.ipynb`. Elles ne sont pas des illustrations génériques.

| Fichier | Contenu |
|---|---|
| `01_repartition_risques.png` | Répartition des classes de risque |
| `02_distribution_age.png` | Distribution de l'âge |
| `03_montant_credit_par_risque.png` | Montant du crédit selon la classe de risque |
| `04_valeurs_extremes_montant_credit.png` | Valeurs extrêmes du montant du crédit |
| `05_matrice_correlation.png` | Corrélations entre variables numériques |
| `06_optimisation_random_forest.png` | Résultats de l'optimisation de Random Forest |
| `07_matrice_confusion.png` | Matrice de confusion sur le jeu de test |
| `08_importance_variables.png` | Importance des variables selon Random Forest |
| `09_cout_selon_seuil.png` | Coût total selon le seuil de décision |

Pour régénérer ces figures, exécuter les cellules correspondantes du notebook.
